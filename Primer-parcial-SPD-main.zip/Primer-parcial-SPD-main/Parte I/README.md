# Integrantes 
Maximiliano Torrez, German Ortega.
# Descripción
Diseño de contador de 0 a 99 utilizando dos displays de 7 segmentos. Se emplea la técnica de multiplexación de displays que consiste en encender un display, apagarlo, y luego encender el otro. Al hacerlo a alta velocidad, para el ojo humano parece que ambos displays están encendidos simultaneamente, cuando en realidad se encienden secuencialmente.
Con tres pulsadores se controla la cuenta: Uno para sumar una unidad, otro para restar una unidad, y el tercero para resetear el contador a 0.
# Link al proyecto
https://www.tinkercad.com/things/e9pLoN4tXBB


