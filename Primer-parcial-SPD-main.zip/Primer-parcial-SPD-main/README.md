# Primer-parcial-SPD
# Integrantes
Maximiliano Torrez, German Ortega.
# Descripción
Parte práctica para del primer parcial de SPD utilizando Arduino en Tinkercad. Se divide en dos partes desarrolladas en sus respectivas carpetas.
